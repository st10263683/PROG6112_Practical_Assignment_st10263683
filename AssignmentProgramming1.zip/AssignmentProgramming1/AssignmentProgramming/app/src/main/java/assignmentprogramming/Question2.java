package assignmentprogramming;

import java.util.ArrayList;
import java.util.Scanner;

class Task {
    private String title;
    private String description;
    private boolean isCompleted;

    public Task(String title, String description) {
        this.title = title;
        this.description = description;
        this.isCompleted = false;
    }

    public void markAsCompleted() {
        this.isCompleted = true;
    }

    public String getTitle() {
        return title;

        
    }

    public String getDescription() {
        return description;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    @Override
    public String toString() {
        return "Task: " + title + "\nDescription: " + description + "\nCompleted: " + isCompleted + "\n";
    }
}

class WorkTask extends Task {
    private String projectName;

    public WorkTask(String title, String description, String projectName) {
        super(title, description);
        this.projectName = projectName;
    }

    public String getProjectName() {
        return projectName;
    }

    @Override
    public String toString() {
        return super.toString() + "Project Name: " + projectName + "\n";
    }
}

class PersonalTask extends Task {
    private String dueDate;

    public PersonalTask(String title, String description, String dueDate) {
        super(title, description);
        this.dueDate = dueDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return super.toString() + "Due Date: " + dueDate + "\n";
    }
}

class TaskManager {
    private ArrayList<Task> tasks;

    public TaskManager() {
        tasks = new ArrayList<>();
    }

    public void addTask(Task task) {
        tasks.add(task);
    }

    public void markTaskCompleted(String title) {
        for (Task task : tasks) {
            if (task.getTitle().equalsIgnoreCase(title)) {
                task.markAsCompleted();
                System.out.println("Task \"" + title + "\" marked as completed.");
                return;
            }
        }
        System.out.println("Task \"" + title + "\" not found.");
    }

    public void displayAllTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks available.");
        } else {
            for (Task task : tasks) {
                System.out.println(task);
            }
        }
    }

    public void generateReport() {
        System.out.println("Task Report:");
        displayAllTasks();
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }
}

public class Question2 {
    private static Scanner scanner = new Scanner(System.in);
    private static TaskManager taskManager = new TaskManager();

    public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    addNewTask();
                    break;
                case 2:
                    markTaskAsCompleted();
                    break;
                case 3:
                    taskManager.displayAllTasks();
                    break;
                case 4:
                    taskManager.generateReport();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("Task Management Application");
        System.out.println("(1) Add New Task");
        System.out.println("(2) Mark Task as Completed");
        System.out.println("(3) Display All Tasks");
        System.out.println("(4) Generate Report");
        System.out.println("(5) Exit");
    }

    private static void addNewTask() {
        System.out.println("Enter task type (1-Work, 2-Personal): ");
        int type = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter title: ");
        String title = scanner.nextLine();

        System.out.print("Enter description: ");
        String description = scanner.nextLine();

        if (type == 1) {
            System.out.print("Enter project name: ");
            String projectName = scanner.nextLine();
            taskManager.addTask(new WorkTask(title, description, projectName));
        } else if (type == 2) {
            System.out.print("Enter due date: ");
            String dueDate = scanner.nextLine();
            taskManager.addTask(new PersonalTask(title, description, dueDate));
        } else {
            System.out.println("Invalid task type.");
        }
    }

    private static void markTaskAsCompleted() {
        System.out.print("Enter task title to mark as completed: ");
        String title = scanner.nextLine();
        taskManager.markTaskCompleted(title);
    }
}




