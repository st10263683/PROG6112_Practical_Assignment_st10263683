
package assignmentprogramming;

class TaskManagerTest {

    public static void main(String[] args) {
        testAddTask();
        testMarkTaskCompleted();
        testGenerateReport();
    }

    public static void testAddTask() {
        TaskManager manager = new TaskManager();
        Task task = new WorkTask("Task1", "Description1", "Project1");
        manager.addTask(task);
        assert manager.getTasks().size() == 1 : "Test Failed: Task was not added correctly.";
        System.out.println("testAddTask passed.");
    }

    public static void testMarkTaskCompleted() {
        TaskManager manager = new TaskManager();
        Task task = new WorkTask("Task1", "Description1", "Project1");
        manager.addTask(task);
        manager.markTaskCompleted("Task1");
        assert manager.getTasks().get(0).isCompleted() : "Test Failed: Task was not marked as completed.";
        System.out.println("testMarkTaskCompleted passed.");
    }

    public static void testGenerateReport() {
        TaskManager manager = new TaskManager();
        Task task1 = new WorkTask("Task1", "Description1", "Project1");
        Task task2 = new PersonalTask("Task2", "Description2", "Tomorrow");
        manager.addTask(task1);
        manager.addTask(task2);
        assert manager.getTasks().size() == 2 : "Test Failed: Tasks were not added correctly.";
        System.out.println("testGenerateReport passed.");
    }
}

