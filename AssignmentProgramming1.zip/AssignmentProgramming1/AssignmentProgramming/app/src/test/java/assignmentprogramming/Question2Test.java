package assignmentprogramming;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class Question2Test {

    @Test
    public void testAddWorkTask() {
        TaskManager manager = new TaskManager();
        WorkTask workTask = new WorkTask("Task1", "Description1", "Project1");
        manager.addTask(workTask);

       
        assertEquals(1, manager.getTasks().size());

        
        assertTrue(manager.getTasks().get(0) instanceof WorkTask);

        // Verify the title and project name
        assertEquals("Task1", manager.getTasks().get(0).getTitle());
        assertEquals("Project1", ((WorkTask) manager.getTasks().get(0)).getProjectName());
    }

    @Test
    public void testAddPersonalTask() {
        TaskManager manager = new TaskManager();
        PersonalTask personalTask = new PersonalTask("Task2", "Description2", "Tomorrow");
        manager.addTask(personalTask);

     
        assertEquals(1, manager.getTasks().size());

        
        assertTrue(manager.getTasks().get(0) instanceof PersonalTask);

        // Verify the title and due date
        assertEquals("Task2", manager.getTasks().get(0).getTitle());
        assertEquals("Tomorrow", ((PersonalTask) manager.getTasks().get(0)).getDueDate());
    }

    @Test
    public void testMarkTaskCompleted() {
        TaskManager manager = new TaskManager();
        WorkTask workTask = new WorkTask("Task1", "Description1", "Project1");
        manager.addTask(workTask);

       
        manager.markTaskCompleted("Task1");

       
        assertTrue(manager.getTasks().get(0).isCompleted());
    }

    @Test
    public void testTaskNotFound() {
        TaskManager manager = new TaskManager();
        WorkTask workTask = new WorkTask("Task1", "Description1", "Project1");
        manager.addTask(workTask);

        // Attempt to mark a non-existent task as completed
        manager.markTaskCompleted("NonExistentTask");

        // Verify that the existing task is still not completed
        assertFalse(manager.getTasks().get(0).isCompleted());
    }

    @Test
    public void testDisplayAllTasks() {
        TaskManager manager = new TaskManager();
        WorkTask workTask = new WorkTask("Task1", "Description1", "Project1");
        PersonalTask personalTask = new PersonalTask("Task2", "Description2", "Tomorrow");
        manager.addTask(workTask);
        manager.addTask(personalTask);

        
        assertEquals(2, manager.getTasks().size());

        // Verify that the tasks are of correct types
        assertTrue(manager.getTasks().get(0) instanceof WorkTask);
        assertTrue(manager.getTasks().get(1) instanceof PersonalTask);
    }
}
